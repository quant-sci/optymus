

def adagrad():
    """
    AdaGrad
    """
    pass

def rmsprop():
    """
    RMSProp
    """
    pass

def adam():
    """
    Adam
    """
    pass

def adamax():
    """
    Adamax
    """
    pass